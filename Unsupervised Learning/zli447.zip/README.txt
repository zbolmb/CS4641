My code was run with the Weka collection of machine learning algorithms.
I had to download a package, the students-filter package in order to use ICA.
I did not have any physical written code, I used the weka GUI.

The data sets were both from the UCI machine learning repository

Diabetic Retinopathy Debrecen Data Set Data Set
Instances: 1151
Attributes: 20
Binary Classification problem

Mammographic Mass Data Set
Instances: 961
Attributes: 6
Binary Classification problem

The raw datasets are attached as well as altered datasets in their respective folders


