My code was run with the Weka collection of machine learning algorithms.
The algorithms I used were Multilayer Perceptron, IBk, SMO, ADABoostM1 and J48.

The data sets were both from the UCI machine learning repository

Diabetic Retinopathy Debrecen Data Set Data Set
Instances: 1151
Attributes: 20
Binary Classification problem

Mammographic Mass Data Set
Instances: 961
Attributes: 6
Binary Classification problem

The code I used was a modification of a few files in ABAGAIL
I took the Abalone test and modified it to run all my tests
Modified Files
MammographicTest.java under opt.test


