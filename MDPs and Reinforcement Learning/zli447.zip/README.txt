Used the same test code from
https://github.com/juanjose49/omscs-cs7641-machine-learning-assignment-4

Used basic reward function of -1 for every action and +100 for the goal.
The transition model was 80% of the time the action is taken, and 20% it takes a different random action.

Used Q-Learning for my RL algorithm.
